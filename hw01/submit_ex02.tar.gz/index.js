function greet(str) {
    console.log(`Hello, ${str}!`);
}

console.log("Hello, world!");

const name = prompt("What is your name?");
greet(name);
